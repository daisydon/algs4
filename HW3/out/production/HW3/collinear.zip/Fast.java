import java.util.Arrays;

/**
 * Created by linyu on 3/3/14.
 */
public class Fast {
        public static void main(String[] args) {
            if (args.length > 0) {
                In reader = new In(args[0]);
                int N = reader.readInt();
                Point[] points = new Point[N];
                for(int i = 0; !reader.isEmpty();i++) {
                    points[i] = new Point(reader.readInt(),reader.readInt());
                    points[i].draw();
                }
                StdDraw.setXscale(0, 32768);
                StdDraw.setYscale(0, 32768);

                //sort the points
                Arrays.sort(points);

                for(int j = 0; j < N; j++) {
                    Point p = points[j];  //origin point p

                    int counter = 0;
                    Point[] list = new Point[N-1];
                    for(Point q: points) {
                        if (!p.equals(q)) {
                            list[counter] = q;
                            counter++;
                        }
                    }

                    Arrays.sort(list, p.SLOPE_ORDER);
                    findCollinear(p, list);
                }
            }

        }
        private static void findCollinear(Point p, Point[] points) {


                for (int i = 0; i < points.length; i++) {
                    Point first = points[i];
                    int j = i + 1;

                    boolean skip = first.compareTo(p) <= 0;
                    while (j < points.length && p.slopeTo(points[j]) == p.slopeTo(first)){
                        skip = skip || points[j].compareTo(p) <= 0;
                        j++;
                    }

                    if (!skip && j - i > 2) {
                        p.drawTo(points[j - 1]);
                        StdOut.print(p);

                        for (int m = i; m < j; m++) {
                            StdOut.print("->");
                            StdOut.print(points[m]);
                        }
                        StdOut.println();
                    }
                    i = j;
                }
            }





}
